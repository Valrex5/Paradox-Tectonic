Cosmetic Megas and Gmax (and Greninja)!

By Valrex
- Version 1.0

-----------------------------

This mod adds the missing Mega Evolutions, Gigantamax and Ash Greninja into the game as purely cosmetic forms accessible through the Universal Formalizer.

List of Pokémon with new forms:
- Venusaur
- Charizard
- Blastoise
- Pidgeot
- Alakazam
- Machamp
- Slowbro
- Gengar
- Snorlax
- Tyranitar
- Sceptile
- Blaziken
- Swampert
- Aggron
- Glalie
- Salamence
- Metagross
- Latias
- Latios
- Greninja
- Diancie
- Melmetal
- Rillaboom
- Cinderace
- Inteleon
- Corviknight
- Orbeetle
- Coalossal
- Flapple
- Appletun
- Hatterene
- Grimmsnarl
- Eternatus
- Urshifu (at the moment not functional)

Planned:
- A method to get the forms separated of the Universal Formalizer.
- Make Urshifu work properly.
- Add follower sprites for the new forms.

-----------------------------
Installation

Drag all the folders in (preferably) a fresh Pokémon Tectonic 3.1.3 install and allow all files to overwrite.

Run the game in debug mode and compile with the batch file included in the installation - this should only be necessary once.
  